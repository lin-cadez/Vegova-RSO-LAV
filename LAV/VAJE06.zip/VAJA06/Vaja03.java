
/**
 Napiši program, ki prebere dve števili
 in sicer maso osebe v kilogramih
 in njeno višino v centimetrih
 
ter na podlagi teh vhodnih podatkov izračuna ITM (indeks telesne mase) osebe.

Formula za izračun ITM je naslednja: (masa [kg]) / (višina[m])2

Na podlagi ITM naj program nato izpiše, ali ima oseba telesno težo:
- premajhno (vrednost ITM pod 18,5),
- normalno (vrednost ITM med 18,5 in 25),
- prekomerno (vrednost ITM med 25 in 30) oz.
- preveliko (vrednost ITM več kot 30).
Bodi pozoren na merske enote.
 */

import java.util.Scanner;
import java.lang.Math.*;

public class Vaja03
{
    public static void main(String[] args){
         Scanner scan = new Scanner(System.in);
         
        System.out.println("Telesna masa (kg): ");
        double mass = Double.valueOf(scan.nextLine());
        System.out.println("Telesna višina (cm): ");
        double height = Double.valueOf(scan.nextLine());
        height /= 100;
        
        double ITM = mass / Math.pow(height, 2);
        
        System.out.printf("Tvoj ITM je %.1f . \n", ITM);
        
        if(ITM < 18.5){
            System.out.println("premajhno (vrednost ITM pod 18,5)");
        }
        else if(ITM < 25){
            System.out.println("normalno (vrednost ITM med 18,5 in 25)");
        }
        else if(ITM < 30){
            System.out.println("prekomerno (vrednost ITM med 25 in 30)");
        }
        else {
            System.out.println("preveliko (vrednost ITM več kot 30)");
        }
        
    }
}

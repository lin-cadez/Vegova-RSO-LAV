
/**
Izdelaj program, ki bere znake in pri tem šteje pojavitve samoglasnikov.

Vnos se konča, ko uporabnik
vnese znak 'x'.

Po koncu vnosa naj program izpiše število pojavitev posameznih samoglasnikov (npr. a
= 2, e = 1, i = 0, o = 0, u = 3).
 */

import java.lang.Math.*;
import java.util.*;
import java.util.Scanner;

public class Vaja09 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int a = 0, e = 0, i = 0, o = 0, u = 0;

        while (true) {
            String in = scan.next().toLowerCase(); 

            if (in.equals("x")) break;
            
            switch (in) {
                case "a": a++; break;
                case "e": e++; break;
                case "i": i++; break;
                case "o": o++; break;
                case "u": u++; break;
                default:
                    System.out.println("Ni samoglasnik"); 
            }
        }

        System.out.printf("a= %d, e = %d, i = %d, o = %d, u = %d", a, e, i, o, u);
    }
}

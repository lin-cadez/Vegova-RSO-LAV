
/**
Napiši program, ki prebere dve števili,
poišče največji skupni delitelj obeh števil ter slednjega izpiše.
 */

import java.util.Scanner;
import java.lang.Math.*;

public class Vaja04
{
    public static void main(String[] args){
         Scanner scan = new Scanner(System.in);
        System.out.println("Number 1: ");
        int a = scan.nextInt();
        System.out.println("Number 2: ");
        int b = scan.nextInt();
      
        int temp = 1;
        int r = 0;
        
        while(temp != 0){
            r = temp;
            temp = a%b;
            a = b;
            b = temp;
        }
        System.out.println(r);
    }
}

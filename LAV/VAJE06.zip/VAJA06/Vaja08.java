
/**
Program
sprašuje po zmnožku naključnih dveh števil med 1 in 10, npr. 'Koliko je 2 x 7?'

Če uporabnik vnese
pravilen odgovor, program izpiše 'Pravilno!', sicer pa 'Nepravilno!'. Program postavi 10 takih vprašanj,
na koncu pa izpiše, koliko pravilnih odgovorov je podal uporabnik (npr. 'Pravilno si odgovoril na 8 od
10 vprašanj!').
 */

import java.lang.Math.*;
import java.util.*;

public class Vaja08
{
    
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        
        int n =0;
        int positive = 0;
        while(n<10){
            int a =(int)(Math.random() * 10 +1);
            int b =(int)(Math.random() * 10 +1);
            
            System.out.printf("Koliko je %dx%d = ", a, b);
            if(a*b == scan.nextInt()){
                System.out.println("pravilno");
                positive++;
            }
            else System.out.println("nepravilno");
            n++;
        }
        System.out.printf("Pravilno si odgovoril na %d od 10 vprašanj", positive);
        
        
    }
}

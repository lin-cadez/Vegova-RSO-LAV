
/**
Oddelek, v katerem je n dijakov, piše kontrolno nalogo pri računalništvu.
Vsak dijak lahko dobi med 0 in 20 točk.

Sestavi program, ki bo omogočal vnos rezultatov n dijakov.
Program ne sme dovoliti vnosa števila točk zunaj intervala [0, 20].



Program naj izračuna in izpiše, koliko je bilo nezadostnih, zadostnih,
dobrih, prav dobrih in odličnih ocen

povprečno oceno.

Meje za dosego posameznih ocen so:
pod 10 točk nezadostno,
od 10 do 12 točk zadostno,
od 13 do 15 točk dobro,
od 15,5 do 17,5 točke prav dobro,
18 ali več točk odlično
 */

import java.util.*;

public class Vaja06
{
    public static void main(String[] args){
         Scanner scan = new Scanner(System.in); 
         ArrayList<Double> arr = new ArrayList<Double>();
         double a, counter = 0;
         
         while(true){
            System.out.println("Stevilo točk: ");
            try{
                a = scan.nextDouble();
                if(a <= 20 && a>=0 && (a%1 == 0 || a%1 == 0.5)){
                    System.out.println("[Potrjeno]");
                    arr.add(a);
                    counter++;
                }
                else{
                     System.out.println("[Neveljavno]");
                }
            }
            catch(Exception e){
                break;
            }
         }
         
         int sum = 0;
         for(int i = 0; i<arr.size(); i++){
             sum += arr.get(i);
         }
         
         int nzd=0, zd=0, db=0, pdb=0, odl = 0;
         for (double i : arr){
             if(i >=18)odl++;
             else if(i >= 15)pdb++;
             else if(i >= 12)db++;
             else if(i >= 10)zd++;
             else nzd++;
         }
         
        System.out.println("_____ Rezultati _____");
         System.out.printf("odl: %d, pdb: %d, db: %d, zd: %d, nzd: %d\n", odl, pdb, db, zd, nzd);
         System.out.printf("Največ točk: %.1f\nNajmanj točk: %.1f\n", Collections.max(arr), Collections.min(arr));
         System.out.printf("Povprečje: %.2f", (double)((nzd + zd*2 + db*3+ pdb*4 +odl*5 )/ (double)arr.size()));
        
    }
}

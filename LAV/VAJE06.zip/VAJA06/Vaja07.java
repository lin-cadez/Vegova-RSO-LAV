
/**
Program naj na začetku ustvari naključno število N, ki naj bo med 1
in 100.

Uporabnik naj ima nato 5 poizkusov, da to število ugane.

Ob vsakem poizkusu vnese število, ki
ga program nato primerja z ustvarjenim ter uporabnika obvesti, ali je uganil, vnesel preveliko ali pa
morda premajhno število.

Če uporabnik v petih poizkusih ne uspe uganiti števila, program izpiše
'Izgubil si!

Iskano število je N', pri čemer izpiše dejansko število.

Če uporabnik pri katerem izmed
poizkusov ugane vrednost iskanega števila, program izpiše 'Zmagal si! Uganil si v M poizkusih.', pri

čemer izpiše dejansko število poizkusov.
 */

import java.lang.Math.*;
import java.util.*;

public class Vaja07
{
    
    public static void main(String[] args){
        int poskusi=1; int a = 0; 
        int N = (int)(Math.random() * 100 + 1);
        Scanner scan = new Scanner(System.in);
   
        while(poskusi <= 5 && (a = scan.nextInt()) !=N){
            System.out.println(a>N? "Preveliko št.":"Premajhno št.");
            poskusi++;
        }
        System.out.println(a == N? "Zmagal si v " + poskusi:"Izgubil si, stevilo je bilo " + N);
        
        
    }
}

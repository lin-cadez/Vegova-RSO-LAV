
/**
Program iz prve naloge predelaj tako,
da deluje pravilno tudi v primeru, ko je prvo vpisano število
večje od drugega.
 */
import java.util.Scanner;
import java.lang.Math.*;


public class Vaja02
{
    
    public static void main(String[] args){
         Scanner scan = new Scanner(System.in);
        System.out.println("Vnesi 3 stevila: ");
    
        int x1 = (int)Integer.valueOf(scan.nextLine());
        int x2 = (int)Integer.valueOf(scan.nextLine());
        int x3 = (int)Integer.valueOf(scan.nextLine());
        
        int temp =  Math.min(x1, x2);
        x2 =  Math.max(x1, x2);
        x1 = temp;

        int counter = 0;
        for(int i = x1; i<=x2; i++)if(i%x3 == 0)counter++;
        
        System.out.println("Stevilo deljivih stevil " + counter); 
        
    }
}

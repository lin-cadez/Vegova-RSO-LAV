
/**
Napiši program, ki prebere tri števila, nato preveri,
koliko števil med prvim in drugim številom
(vključno-vključno) je deljivih s tretjim številom ter to izpiše.
 */
import java.util.Scanner;

public class Vaja01
{
    public static void main(String[] args){
         Scanner scan = new Scanner(System.in);
        System.out.println("Vnesi 3 stevila: ");
    
        int x1 = (int)Integer.valueOf(scan.nextLine());
        int x2 = (int)Integer.valueOf(scan.nextLine());
        int x3 = (int)Integer.valueOf(scan.nextLine());

        int counter = 0;
        for(int i = x1; i<=x2; i++)if(i%x3 == 0)counter++;
        
        System.out.println("Stevilo deljivih stevil " + counter); 
        
    }
    
}

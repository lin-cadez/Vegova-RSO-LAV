/**
Napiši program, ki prebere tri števila ter izpiše njihovo 
vsoto,
zmnožek,
povprečno vrednost, 
najmanjše
in največje število.


Primer izpisa:
Prvo število: 3
Drugo število: 2
Tretje število: 10
Vsota je 15.
Zmnožek je 60.
Povprečna vrednost je 5.
Najmanjše število je 2.
Največje število je 10
 */
import java.util.*;
import java.lang.Math.*;


public class Vaja05
{
    public static void main(String[] args){
         Scanner scan = new Scanner(System.in);
        System.out.println("Prvo število: ");
        int a = scan.nextInt();
        System.out.println("Drugo število: ");
        int b = scan.nextInt();
         System.out.println("Tretje število: ");
        int c = scan.nextInt();     
        int arr[]={a, b, c};
        Arrays.sort(arr);
      
        System.out.printf("Vsota je %d\n", c+a+b);
        System.out.printf("Zmnožek je %d\n", a*b*c);
        System.out.printf("Povprečna vrednost je %d\n", (a+b+c)/3);
        System.out.printf("Najmanjše število je %d\n", arr[0]);
        System.out.printf("Največje število je %d\n", arr[arr.length -1]);
    }
}

import java.util.Random;


public class vaja07{

    public static void main(String[] args){
        Random rand = new Random();
        int dolz1 = rand.nextInt(30) + 1;
        int dolz2 = rand.nextInt(30) + 1;
        int dolz3 = rand.nextInt(30) + 1;
        
         System.out.printf("dolz1: %d\ndolz2: %d\ndolz3: %d\n", dolz1, dolz2, dolz3);
         System.out.printf("Ali je dolz1 daljša od dolz2? %b", dolz1 > dolz2);
    }
}

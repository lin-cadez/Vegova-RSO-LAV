
/**
Ocenite trenutni kot, ki ga oklepa minutni kazalec ure z vodoravno osjo. 

deklarirali in inicializirali spremenljivko z ocenjenim kotom

stopinjah
radianih
gradih
 */

import java.lang.Math.*;

public class vaja01
{
    // instance variables - replace the example below with your own
   public static void main(int minute){
       double angle = Math.abs(((minute % 60) * 6) - 90);
        angle = Math.min(angle, 180 - angle);
        
       System.out.println("stopinje: " + angle);
       System.out.println("radiani: " + Math.toRadians(angle));
       System.out.println("gradiani: " + angle * 9/10);
       
   }
}


/**
 Recimo, da si izberemo neko neceloštevilsko vrednost.
 
 Program primerja vrednost celega dela (tistega pred
decimalno vejico)
z vrednostjo necelega dela (za decimalno vejico

 kot da bi bili to dve celoštevilski vrednosti,
ter ustrezno rezultatu primerjave izpiše pravilno (če je celi večji) ali nepravilno (če je celi del manjši). Recimo, da
sta celi in neceli del vedno dolžine 4 decimalnih mest.
 */

import java.lang.Math.*;

public class vaja03 {
    public static void main(double input) {
        //1234.5678
        
        int x = (int)input;
        int y = (int)(input%1 * 10000);
        
        System.out.println(x>y? "true" : "false");
        
    }
}

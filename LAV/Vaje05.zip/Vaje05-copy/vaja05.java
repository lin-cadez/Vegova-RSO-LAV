
/**
 Javanski program ustvari 5 naključnih vrednosti z intervala [0, 17]
 
 Nato izpiše najmanjšo vrednost izmed
ustvarjenih kot 

'Najmanjša ustvarjena vrednost je xx' in največjo vrednost kot 'Največja ustvarjena vrednost je
yy)


. Spišite ga.
 */

import java.lang.Math.*;
import java.util.*;

public class vaja05
{
    public static void main(){
        Random rand = new Random();
        int[] seznam = new int[5];
        
        for(int i=0; i<5; i++){
            System.out.println(seznam[i] = rand.nextInt(18));
        }
        
        
        
        int smallest = 0;
        for(int i=0; i<seznam.length; i++){
            if(seznam[smallest] > seznam[i]){
                smallest=i;
            }
        }
        
        int biggest = 0;
        for(int i=0; i<seznam.length; i++){
            if(seznam[biggest] < seznam[i]){
                biggest=i;
            }
        }
        
        System.out.printf("\nNajmanjša ustvarjena vrednost je %d.", seznam[smallest]);
        System.out.printf("\nNajvečja ustvarjena vrednost je %d.", seznam[biggest]);
    }
}

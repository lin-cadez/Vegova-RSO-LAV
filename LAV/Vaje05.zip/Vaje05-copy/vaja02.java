
/**
 Javanski program opredeli podatek za poljubno neceloštevilsko vrednost z intervala
 -10 do 110 (izberite si jo
sami). Privzemite, da ta vrednost predstavlja
temperaturo v stopinjah Celzija, ki pa bi jo želeli izraziti glede na
lestvice : 

Kelvin, Fahrenheit, Rømer, Delisle, Réaumur,Rankine, Newton.
Preračun iz teh v stopinje Celzija se

izvede:
C = (F -32 ) * 9/5;
C = (K+273.15);
C = (R - 7.5) * 1.9047619; danska skala oz. Rømer
C = (150 - D) * 2/3; Delisle
C = (R - 491.67) / 1.79999999; Rankine
C = R * 1.25; Réaumur
C = N * 3.03030303;

Napišite program, program naj izpiše tudi vreliščne in lediščne vrednosti za vse omenjene lestvice
 */
public class vaja02 {
    public static void main(double celzija) {
        if (!(celzija > -10.0 && celzija < 110.0)) {
            System.out.println("Prevelika/premajhna cifra");
            return;
        }
        
        System.out.println("C: " + celzija + " °C");
        
        // Kelvin
        double kelvin = celzija - 273.15;
        System.out.println(kelvin + " K");

        // Fahrenheit
        double fahrenheit = (celzija * 9 / 5) + 32;
        System.out.println(fahrenheit + " °F");

        // Rømer
        double romer = (celzija * 21 / 40) + 7.5;
        System.out.println(romer + " °Rø");

        // Delisle
        double delisle = (100 - celzija) * 3 / 2;
        System.out.println(delisle + " °De");

        // Réaumur
        double reaumur = celzija * 0.8;
        System.out.println(reaumur + " °Ré");

        // Rankine
        double rankine = (celzija + 273.15) * 9 / 5;
        System.out.println(rankine + " °Ra");

        // Newton
        double newton = celzija * 33 / 100;
        System.out.println(newton + " °N");
        
        System.out.println("\nBoiling and Freezing Points:");
        
        double freezingCelsius = 0;
        double boilingCelsius = 100;

        System.out.println("Celsius: " + freezingCelsius + " °C (Freezing), " + boilingCelsius + " °C (Boiling)");

        double freezingKelvin = freezingCelsius + 273.15;
        double boilingKelvin = boilingCelsius + 273.15;
        System.out.println("Kelvin: " + freezingKelvin + " K (Freezing), " + boilingKelvin + " K (Boiling)");

        double freezingFahrenheit = (freezingCelsius * 9 / 5) + 32;
        double boilingFahrenheit = (boilingCelsius * 9 / 5) + 32;
        System.out.println("Fahrenheit: " + freezingFahrenheit + " °F (Freezing), " + boilingFahrenheit + " °F (Boiling)");

        double freezingRomer = (freezingCelsius * 21 / 40) + 7.5;
        double boilingRomer = (boilingCelsius * 21 / 40) + 7.5;
        System.out.println("Rømer: " + freezingRomer + " °Rø (Freezing), " + boilingRomer + " °Rø (Boiling)");

        double freezingDelisle = (100 - freezingCelsius) * 3 / 2;
        double boilingDelisle = (100 - boilingCelsius) * 3 / 2;
        System.out.println("Delisle: " + freezingDelisle + " °De (Freezing), " + boilingDelisle + " °De (Boiling)");

        double freezingReaumur = freezingCelsius * 0.8;
        double boilingReaumur = boilingCelsius * 0.8;
        System.out.println("Réaumur: " + freezingReaumur + " °Ré (Freezing), " + boilingReaumur + " °Ré (Boiling)");

        double freezingRankine = (freezingCelsius + 273.15) * 9 / 5;
        double boilingRankine = (boilingCelsius + 273.15) * 9 / 5;
        System.out.println("Rankine: " + freezingRankine + " °Ra (Freezing), " + boilingRankine + " °Ra (Boiling)");

        double freezingNewton = freezingCelsius * 33 / 100;
        double boilingNewton = boilingCelsius * 33 / 100;
        System.out.println("Newton: " + freezingNewton + " °N (Freezing), " + boilingNewton + " °N (Boiling)");
    }
}


/**
Javanski program ugotovi ali se krožnici z radijem r1 in r2,
prva v izhodišču(x1,y1) in druga v (x2,y2) sekata

ter
ugotovitev izpiše v obliki pravilno (se sekata) in nepravilno
(se ne sekata).


lahko naključno ustvarite z intervala npr. [1,6].
(preverite: k1(1,1) z r=1 in k2(3,3) z r=1 se ne sekata,…
 */
public class vaja04
{
    
    public static void Intersection(int x1, int y1, int r1, int x2, int y2, int r2){
        System.out.println(((x1-r1 <= x2 - r2 && x1+r1 >= x2 - r2 || x1-r1 <= x2 + r2 && x1+r1 >= x2 + r2)||(y2 + r2 >= y1-r1 && y2 + r2 <= y1+r1 || y2 - r2 >= y1-r1 && y2 - r2 <= y1+r1)? "Seka" : "Ne seka"));

    }
    
    public static void main(String[] args){
        Intersection(1, 1, 1, 5, 0, 15);
    }
}


/**
ravnina 30*30
x1, x2, y1, y2

izračunaj ploščino
izpis točk
obseg

 */
import java.util.*;

public class vaja06
{
    
    public static void main(String[] args){
        Random rand= new Random();
        
        int x1 = rand.nextInt(31);
        int y1 = rand.nextInt(31);
        
        int x2 = rand.nextInt(31);
        int y2 = rand.nextInt(31);
            
        //Preveri ali je točka v danem območju
        if (x1 > 30 || x2 > 30 || y1 > 30 || y2 > 30) return;
        
        System.out.printf("1: (%d, %d)\n", x1, y1);
        System.out.printf("2: (%d, %d)\n", x2, y2);
        System.out.printf("Ploščina: %d\n", Math.abs(x1-x2) * Math.abs(y2-y1));
        System.out.printf("Obseg: %d", Math.abs(x1-x2) * 2 + 2* Math.abs(y2-y1));
 
    } 
}

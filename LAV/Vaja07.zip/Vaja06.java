
/**
 *n=6
 
 
0 1 2 3 4 5
0 1 2 3 4
0 1 2 3
0 1 2
0 1
0
 */
public class Vaja06
{
    public static void main(int n){
        int x =n;
        for(int i = 0; i<x; i++){
            for(int j = 0; j<n; j++){
                System.out.print(j + " ");
                
            }
            System.out.println();
            n--;
        }
        
        
    }
    
}


/**
Program naj razstavi s parametrom vneseno število na posamezne števke.
Vsako števko podanega števila naj
izpiše v drugi vrstici. Npr.:
>java V4n4 2319
2
3
1
9
 */
import java.lang.Math.*;

public class Vaja04
{
    public static void main(int N){
        int x =N;
        int count = 0;
        while(x/10 > 0){
            count++;
            x/=10;
        }
        count=(int)Math.pow(10, count);
        while(N>0){
            System.out.println(N/count);
            N%=count;
            count/=10;
        }
    }
}

public class Vaja12 {
    public static void main(String[] args) {
        int n = 6;
        for (int i = 0; i < n; i++) {
            for (int z = n - i - 1; z > 0; z--) System.out.print("  ");
            for (int j = i, temp = 1; j >= 0; j--, temp = 0) System.out.print(temp == 1 ? j + " " : "  ");
            for (int j = 1; j <= i; j++) System.out.print(j == i ? j + " " : "  ");
            System.out.println();
        }
        for (int i = 0, x = n; i < x; i++) {
            for (int z = x - n; z >= 0; z--) System.out.print("  ");
            for (int j = n - 2, temp = 1; j >= 0; j--, temp = 0) System.out.print(temp == 1 ? j + " " : "  ");
            for (int c = 1; c < n - 1; c++) System.out.print(c == n - 2 ? c + " " : "  ");
            System.out.println();
            n--;
        }
    }
}

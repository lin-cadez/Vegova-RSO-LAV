
/**
Napišite javanski program ki na zaslon izriše kvadrat s števkami N s stranico
 */

public class Vaja02
{
    public static void main(int N){
     
        
for (int x = N; x > 0; x--) {
            for (int j = N; j > 0; j--) {
                System.out.print(N);
            }
            System.out.println();
    }
}

}



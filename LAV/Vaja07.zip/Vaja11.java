
/**
n=6
0
0 1
0 1 2
0 1 2 3
0 1 2 3 4
0 1 2 3 4 5

 */
public class Vaja11
{
    public static void main(String args[]){
        int n = 6;
        for(int i = 0; i<n; i++){
            for(int z=(n-i - 1); z>0; z--){
                System.out.print("  ");
            }
            for(int j=i; j>=0; j--){
                System.out.print(j + " ");
            }
            for(int j=1; j<=i; j++){
                System.out.print(j + " ");
            }
            
            System.out.println();
         
        }
        int x =n;
        for(int i = 0; i<x; i++){
            for(int z = x-(n ); z>=0; z--){
                System.out.print("  ");
                
            }
            for(int j = n-2; j>=0; j--){
                System.out.print(j + " ");
                
            }
            for(int c =1; c<n-1; c++){
               System.out.print(c + " ");
           }
            System.out.println();
            n--;
        }
        
    }
    
}

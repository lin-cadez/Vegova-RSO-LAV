
/**
321
21
 */
public class Vaja03
{
    public static void main(int N){
        int x= N;
        
        
        while(N>1){ 
            int z =(x-N);
            while(z>0){
                System.out.print(" ");
                z--;
            }
            int j=N;
            while( j>0){
                System.out.print(j); 
                j--;
            }           
            System.out.println();
            N--;
        }
    }
}


/**
n=6
0
1 0
2 1 0
3 2 1 0
4 3 2 1 0
5 4 3 2 1 0

 */
public class Vaja08
{
    public static void main(int n){
        int x = n;
        for(int i = 0; i<n; i++){
            for(int z=(n-i - 1); z>0; z--){
                System.out.print(" ");
            }
            for(int j=i; j>=0; j--){
                System.out.print(j);
            }
            
            System.out.println();
         
        }
        
        
    }
    
}

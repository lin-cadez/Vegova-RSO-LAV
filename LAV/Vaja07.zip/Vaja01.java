
/**
Napišite javanski program, ki vrednost N na zaslon izpiše N-krat
 N naj bo pri tem vhodni parameter programa.
 
Izvedba programa s parametrom 6:

>java V4n1 6
666666
 */
public class Vaja01
{
    public static void main(int N){
        int i=0;
        while(i<N){
            System.out.print(N);
            i++;
        }
    }
}

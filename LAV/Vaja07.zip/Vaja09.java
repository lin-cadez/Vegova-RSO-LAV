
/**
n=6
0
0 1
0 1 2
0 1 2 3
0 1 2 3 4
0 1 2 3 4 5

 */
public class Vaja09
{
    public static void main(int n){
        int x = n;
        for(int i = 0; i<n; i++){
            for(int j=0; j<=i; j++){
                System.out.print(j + " ");
            }
            
         
            
            System.out.println();
         
        }
        
        
    }
    
}
